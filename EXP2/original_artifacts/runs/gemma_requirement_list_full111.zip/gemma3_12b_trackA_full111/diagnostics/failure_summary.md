# Failure ledger summary

_Ledger is empty._
