import csv
import hashlib
import json
import re
import sys
import unittest
from pathlib import Path
from unittest import mock

import requirement_provider as rp
import run_exp2
import judge_panels as jpanel
import probe_engine as pe
import probe_roundtrip as prt
import probe_schemas as pschema
import shadow_witness_architecture as swa
import track_b
import track_b_localization as tbl


HERE = Path(__file__).resolve().parent
EXPECTED_WITNESS_PROMPT_SHA256 = (
    "e17faff1d84aef20bf21407cdb188967a4f897e7dae9847fe1d2702e80d7d7d5")
EXPECTED_ROOT_PROMPT_SHA256 = (
    "07ce8589e38b8cd6dd1c04eeb1be7b4d5152629f50c726c8009ba98cd6e7aa0a")


class ReleaseContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = json.loads(
            (HERE / "frozen_assets/Problems_main.json").read_text(encoding="utf-8"))
        with (HERE / "reports/requirement_changelog.csv").open(
                newline="", encoding="utf-8-sig") as handle:
            cls.changelog = list(csv.DictReader(handle))

    def test_candidate_design_is_original_111(self):
        self.assertEqual(
            run_exp2.validate_full_candidate_design(run_exp2.load_candidates()),
            {"candidates": 111, "bases": 29, "mutants": 82, "problems": 29})

    def test_all_approved_texts_and_original_categories_are_exact(self):
        self.assertEqual(len(self.changelog), 523)
        problems = {str(p["id"]): p for p in self.catalog["pilot_problems"]}
        for row in self.changelog:
            requirement = next(
                r for r in problems[row["problem_id"]]["requirements"]
                if str(r["requirement_id"]) == row["requirement_id"])
            self.assertEqual(row["category_changed"].strip().lower(), "no")
            self.assertEqual(requirement["category"], row["old_category"])
            self.assertEqual(requirement["category"], row["new_category"])
            self.assertEqual(requirement["requirement_text"],
                             row["new_requirement_text"])

    def test_no_note_or_warning_field_or_text_remains_in_catalog(self):
        def visit(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    self.assertIsNone(re.search(r"note|warning", key, re.I), key)
                    visit(item)
            elif isinstance(value, list):
                for item in value:
                    visit(item)
            elif isinstance(value, str):
                self.assertIsNone(re.search(r"\b(?:note|warning)s?\b", value, re.I))
        visit(self.catalog)

    def test_probe_generator_receives_full_problem_narrative(self):
        payload = {
            "problem_description": "FULL NARRATIVE SENTINEL",
            "data_instance": {"demand": 7},
        }
        requirement = {
            "requirement_id": "R_test", "requirement_text": "x >= 7",
            "category": "constraint",
        }
        prompt = track_b._probe_prompt(
            payload, requirement, {"variables": [{"name": "x"}]},
            ["linear_requirement_probe"], {}, "")
        self.assertIn("FULL PROBLEM DESCRIPTION/NARRATIVE", prompt)
        self.assertIn("FULL NARRATIVE SENTINEL", prompt)

    def test_only_retained_probe_aware_witness_and_root(self):
        self.assertEqual(swa.ARCHITECTURE_NAME, "probe_aware_root")
        self.assertFalse(hasattr(swa, "verify_witness"))
        self.assertFalse(hasattr(swa, "combine_verifiers"))
        self.assertEqual(hashlib.sha256(
            swa.WITNESS_VERIFIER_PROMPT.encode()).hexdigest(),
            EXPECTED_WITNESS_PROMPT_SHA256)
        self.assertEqual(hashlib.sha256(swa.ROOT_CAUSE_PROMPT.encode()).hexdigest(),
                         EXPECTED_ROOT_PROMPT_SHA256)

    def test_final_verdicts_are_three_way_only(self):
        self.assertEqual(rp.VALID_VERDICTS,
                         ("correct", "incorrect", "pipeline_error"))
        self.assertEqual(run_exp2.FINAL_VERDICTS,
                         ("correct", "incorrect", "pipeline_error"))

    def test_runner_main_has_no_stale_runtime_initializer(self):
        with mock.patch.object(run_exp2, "run") as run_mock, \
                mock.patch.object(
                    sys, "argv", ["run_exp2.py", "--config", "track_b"]):
            self.assertEqual(run_exp2.main(), 0)
        run_mock.assert_called_once()

    def test_requirement_technical_failure_stays_unresolved(self):
        self.assertEqual(
            track_b._unresolved_requirement_label(True),
            "UNRESOLVED")
        self.assertEqual(
            track_b._unresolved_requirement_label(False),
            "UNRESOLVED")

    def test_requirement_unresolved_does_not_force_candidate_pipeline_error(self):
        self.assertEqual(track_b._aggregate_candidate_verdict([]), "correct")
        self.assertEqual(
            track_b._aggregate_candidate_verdict(["R_confirmed"]), "incorrect")
        self.assertFalse(track_b._systemic_requirement_failure(30, 1))
        self.assertTrue(track_b._systemic_requirement_failure(30, 27))
        source = (HERE / "track_b.py").read_text(encoding="utf-8")
        self.assertNotIn("STRUCTURAL_PASS_LAST_RESORT", source)

    def test_all_requirements_receive_identical_template_pool(self):
        first = pe.compatible_templates({
            "category": "integrality", "requirement_text": "variables are integer"})
        second = pe.compatible_templates({
            "category": "flow_balance", "requirement_text": "outbound flow equals demand"})
        self.assertEqual(first, second)
        self.assertEqual(first, list(pe.SEMANTIC_TEMPLATE_POOL))
        self.assertEqual(first[0], "linear_requirement_probe")
        for template in first:
            schema = pschema.probe_schema(template, "R_test")
            self.assertEqual(
                schema["properties"]["probe_template"]["enum"], [template])

    def test_judges_allow_only_accept_or_repair(self):
        self.assertEqual(prt.VERDICTS, ("ACCEPT", "REPAIR"))
        self.assertFalse(hasattr(prt, "REJECT"))
        self.assertFalse(hasattr(jpanel, "REJECT"))
        schema = pschema.judge_decision_schema("R_test", "mathematical_correctness")
        self.assertEqual(schema["properties"]["verdict"]["enum"], ["ACCEPT", "REPAIR"])
        self.assertEqual(prt.tally_panel(["ACCEPT", "ACCEPT"])["action"],
                         prt.ACTION_EXECUTE)
        self.assertEqual(prt.tally_panel(["ACCEPT", "REPAIR"])["action"],
                         prt.ACTION_RECONSTRUCT)

    def test_judge3_sees_claim_and_exact_executable(self):
        captured = {}

        def call_json(prompt, _seed, _tokens):
            captured["prompt"] = prompt
            return ({
                "requirement_id": "R_test", "judge": "executable_equivalence",
                "verdict": "ACCEPT", "patch": {}, "reason": "equivalent",
                "confidence": 1.0,
            }, "", {})

        executable = {
            "requirement_id": "R_test", "probe_template": "linear_requirement_probe",
            "claim": "0.2I + 0.4II = own + external", "parameters": {
                "lhs_terms": [{"var": "I", "coeff": 0.2}], "sense": "==", "rhs": 0.0}}
        audit = []
        record = jpanel._judge3_executable_equivalence(
            call_json, {"requirement_id": "R_test", "requirement_text": "balance",
                        "category": "balance"}, executable["claim"], executable, {},
            seed_for=lambda *_: 1, audit=audit)
        self.assertEqual(record["verdict"], "ACCEPT")
        self.assertIn("GENERATED CLAIM", captured["prompt"])
        self.assertIn("EXACT FINAL NORMALIZED EXECUTABLE PROBE", captured["prompt"])
        self.assertIn("0.2I + 0.4II = own + external", captured["prompt"])

    def test_judge_stages_have_the_approved_execution_order(self):
        source = (HERE / "track_b.py").read_text(encoding="utf-8")
        first_two = source.index("first_two_record = _panel_gate")
        normalize = source.index("probe = pe.normalize_probe", first_two)
        third = source.index("third_record = _panel_gate", normalize)
        execute = source.index("result = pe.execute_probe", third)
        self.assertLess(first_two, normalize)
        self.assertLess(normalize, third)
        self.assertLess(third, execute)

    def test_witness_verifier_semantic_domain_is_yes_no_only(self):
        schema = pschema.witness_verifier_schema()
        self.assertEqual(schema["properties"]["decision"]["enum"], ["YES", "NO"])
        self.assertEqual(swa._normalise_verifier_decision("YES"), "YES")
        self.assertEqual(swa._normalise_verifier_decision("NO"), "NO")
        self.assertEqual(swa._normalise_verifier_decision("CANNOT_TELL"), "")

    def test_witness_verifier_no_is_a_decision_not_pass(self):
        certificate = {
            "eligible_for_llm_review": True, "ineligible_reason": "",
            "variable_names": [], "candidate_point": {"x": 1.0},
            "observations": [], "provenance": {},
        }

        def call_json(_prompt, _seed, _tokens):
            return ({"requirement_demands": "x >= 2", "decisive_check": "x=1",
                     "reason": "witness does not establish this rule", "decision": "NO"},
                    "", {"text": ""})

        with mock.patch.object(swa, "build_witness_certificate", return_value=certificate):
            record = swa.verify_probe_aware(
                {"requirement_id": "R_test", "requirement_text": "x >= 2"}, {},
                {"normalized_probe": {}}, {}, call_json=call_json,
                model="fixture", seed=1)
        self.assertEqual(record["status"], "DECIDED")
        self.assertEqual(record["decision"], "NO")
        self.assertEqual(swa.WITNESS_V_REJECT, "WITNESS_V_REJECT")
        self.assertNotEqual(record["status"], "PASS")
        source = (HERE / "track_b.py").read_text(encoding="utf-8")
        self.assertIn("official_result_labels[rid] = swa.WITNESS_V_REJECT", source)

    def test_witness_verifier_technical_failure_bypasses_yes_no(self):
        certificate = {
            "eligible_for_llm_review": True, "ineligible_reason": "",
            "variable_names": [], "candidate_point": {"x": 1.0},
            "observations": [], "provenance": {},
        }

        def call_json(_prompt, _seed, _tokens):
            return None, "timeout", {"text": ""}

        with mock.patch.object(swa, "build_witness_certificate", return_value=certificate):
            record = swa.verify_probe_aware(
                {"requirement_id": "R_test", "requirement_text": "x >= 2"}, {},
                {"normalized_probe": {}}, {}, call_json=call_json,
                model="fixture", seed=1)
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertIsNone(record["decision"])
        self.assertIn("timeout", record["technical_reason"])

    def test_bound_probe_uses_full_model_solver_when_declaration_is_weaker(self):
        inventory = {
            "variables": [{"name": "z", "vtype": "C", "lb": 0.0, "ub": 100.0}],
            "constraints": [], "objective": {"sense": "minimize", "terms": []},
        }
        probe = {
            "probe_id": "bound", "requirement_id": "R_bound",
            "probe_template": "check_variable_property", "claim": "z <= 95",
            "parameters": {"target_variables": ["z"], "property": "upper_bound",
                           "expected_value": 95.0},
        }
        no_witness = {"status": "NO_WITNESS", "solver_calls": 1,
                      "message": "maximum z is 84", "tests": []}
        with mock.patch.object(pe, "_execute_subprocess_probe", return_value=no_witness):
            result = pe.execute_probe(probe, inventory, "", {})
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["solver_calls"], 1)
        self.assertEqual(result["structural_status"], "REQUIRES_SOLVER")
        witness = {
            "status": "WITNESS_FOUND", "solver_calls": 1,
            "message": "maximum z is 97", "tests": [],
            "post_validation_confirmed": True,
            "arithmetic_replay_agrees": True,
            "full_model_replay": {"feasible": True},
        }
        with mock.patch.object(pe, "_execute_subprocess_probe", return_value=witness):
            result = pe.execute_probe(probe, inventory, "", {})
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["witness_status"], "WITNESS_FOUND")
        self.assertTrue(result["full_model_replay"]["feasible"])
        evidence = tbl.classify_fail({
            "requirement_id": "R_bound", "normalized_probe": probe,
            "decision_source": "probe_witness", "result_label": "PROBE_FAIL",
            "execution_result": {
                "structural_status": "REQUIRES_SOLVER",
                "witness_status": "WITNESS_FOUND",
                "full_model_replay": {"feasible": True}},
        })
        self.assertEqual(evidence["evidence_tier"], 3)

    def test_result_row_records_completion_fields(self):
        row = run_exp2._result_row(
            {"candidate_id": "c", "candidate_kind": "base", "problem_id": 1},
            {"verdict": "correct"},
            {"prediction_valid": True, "unresolved_requirement_count": 1,
             "evaluation_complete": False}, model="fixture", repetition=1, seed=1)
        self.assertEqual(row["unresolved_requirement_count"], 1)
        self.assertFalse(row["evaluation_complete"])
        fatal = track_b._blank_accounting("fatal")
        self.assertEqual(fatal["pipeline_error_count"], 1)
        self.assertFalse(fatal["evaluation_complete"])

    def test_original_v42_context_preflight_is_runner_managed(self):
        source = (HERE / "run_exp2.py").read_text(encoding="utf-8")
        self.assertIn("rctx.verify_requested_context(", source)
        self.assertIn("cpreflight.build_rows(", source)
        self.assertIn("cpreflight.assert_all_safe(", source)
        self.assertNotIn("configure_runtime", source)



if __name__ == "__main__":
    unittest.main()
