# Release validation

## Approved requirement application

- Changelog SHA-256: `c35b53cd93692e87a5f6ea45736f90e4fc22ed56837c4a3838e73bf8485249b0`
- Changelog rows mapped uniquely to active requirements: 523/523
- Approved final texts applied exactly: 523/523
- Changelog rows marked `text_changed=yes`: 522
- Changelog rows marked `text_changed=no`: 1
- Final texts differing from the supplied original archive: 523
- Active original V42 categories changed: 0/523
- All catalog categories changed: 0/1,292
- Changelog used as experimental feedback: no

## Catalog cleanup

- Note/warning fields removed from `Problems_main.json`: 210
- Dangling reference to a removed warning field removed: 1
- Remaining note/warning keys or prose in `Problems_main.json`: 0
- Unexpected catalog changes: 0

## Runtime architecture

- Architecture: `probe_aware_root`
- Probe-aware witness verifiers: 1
- Root-cause adjudicators: 1
- Blind witness verifier: absent
- Dual/consensus decision logic: absent
- Judge decisions: `ACCEPT`, `REPAIR` only
- Judge 3 prompt SHA-256: `44321faa7351cd792767dc15fe7438f2df24cb00456b9c5e0b88370a76340174`
- Witness decisions: `YES`, `NO` only
- Witness prompt SHA-256: `e17faff1d84aef20bf21407cdb188967a4f897e7dae9847fe1d2702e80d7d7d5`
- Root prompt SHA-256: `07ce8589e38b8cd6dd1c04eeb1be7b4d5152629f50c726c8009ba98cd6e7aa0a`
- Full problem narrative in every probe-generation prompt: verified
- Requirement template pools: identical for every requirement
- Common template pool definitions: 9/9 schema-backed
- Keyword/category template restriction or reordering: absent
- Original V42 category values changed: 0
- Runtime imports of offline scorer or mutant labels: none
- Final verdicts: `correct`, `incorrect`, `pipeline_error`

## Static checks

- Python compilation: PASS
- Prompt/config freeze verification: PASS (98 constants)
- Unit tests: PASS (33/33)
- Candidate design: PASS (111 = 29 bases + 82 mutants)
- Prompt payload construction: PASS for all 29 base problems, each with a nonempty narrative
- Unchanged protected assets: PASS (124/124)
- Cache scan before packaging: PASS
- Original cleanup file decisions: 131 KEEP, 16 MODIFY, 15 ADD, 1,341 DELETE
- Approved A–E overlay relative to the execution-fixed release: 19 files modified, 0 added,
  0 deleted

## Execution compatibility

- Stale `runtime_context.configure_runtime` call: removed
- Original V42 internal context and full-prompt preflight: restored
- Requirement-local generation/normalization/compilation/judging/execution failure: `UNRESOLVED`
- Requirement-local technical failure forces candidate `pipeline_error`: no
- `unresolved_requirement_count`: recorded
- `evaluation_complete`: false whenever any requirement is unresolved
- Witness `NO` label: `WITNESS_V_REJECT` (unresolved, never PASS)
- Fatal candidate-level exception remains `pipeline_error`: yes
- Pervasive technical collapse across at least 90% of a multi-requirement evaluation: system-level
  `pipeline_error`
- Freeze failures report exact mismatched entries: yes

## Experiment execution

No experiment and no end-to-end Gurobi execution were run. A synthetic bound-path unit test verifies
that a weaker declared bound invokes the full-model solver path, solver `NO_WITNESS` maps to PASS,
and a replay-confirmed `WITNESS_FOUND` maps to FAIL. `gurobipy` is unavailable in this validation
environment, so this test uses the existing subprocess boundary with mocked solver responses..

## Release blockers

No static release blockers remain. End-to-end solver execution is intentionally unperformed.
