#!/usr/bin/env python3
"""Contract tests for objective_difference_probe and the retired decision values."""
from __future__ import annotations

import unittest
from unittest import mock

import probe_engine as pe
import probe_schemas as ps


REQ = {"requirement_id": "R_obj", "category": "objective",
       "requirement_text": "The objective must minimize 3 x + 4 y."}
INVENTORY = {"variables": [{"name": "x", "vtype": "C", "lb": 0, "ub": None},
                           {"name": "y", "vtype": "C", "lb": 0, "ub": None}],
             "objective": {"sense": "minimize",
                           "terms": [{"var": "x", "coeff": 3}, {"var": "y", "coeff": 4}]}}


def probe(terms=None, sense="minimize", constant=0.0, tolerance=1e-6):
    return {"probe_id": "p1", "requirement_id": "R_obj",
            "probe_template": "objective_difference_probe", "claim": "objective",
            "parameters": {"required_objective": {
                "sense": sense,
                "terms": terms if terms is not None else [{"var": "x", "coeff": 3.0},
                                                          {"var": "y", "coeff": 4.0}],
                "constant": constant},
                "tolerance": tolerance}}


def run_with(harness_result):
    with mock.patch.object(pe, "_execute_subprocess_probe", return_value=harness_result):
        return pe.execute_probe(probe(), INVENTORY, "code", {})


class TemplatePool(unittest.TestCase):
    def test_objective_difference_probe_is_offered_to_every_requirement(self):
        self.assertIn("objective_difference_probe", pe.SEMANTIC_TEMPLATE_POOL)
        self.assertEqual(list(pe.compatible_templates(REQ)), list(pe.SEMANTIC_TEMPLATE_POOL))

    def test_not_probeable_is_retired_everywhere(self):
        self.assertNotIn("not_probeable", pe.SEMANTIC_TEMPLATE_POOL)
        self.assertNotIn("not_probeable", pe.SUPPORTED_TEMPLATES)
        self.assertNotIn("not_probeable", pe.template_guide())

    def test_no_active_cannot_tell_or_reject_decision_values(self):
        source = open(pe.__file__, encoding="utf-8").read()
        self.assertNotIn("CANNOT_TELL", source)


class Verdicts(unittest.TestCase):
    def test_agreement_passes(self):
        out = run_with({"status": "NO_DIFFERENCE", "solver_calls": 2,
                        "tests": [{"name": "max_difference", "outcome": "OPTIMAL", "value": 0.0},
                                  {"name": "min_difference", "outcome": "OPTIMAL", "value": 0.0}]})
        self.assertEqual(out["status"], "PASS")
        self.assertEqual(out["evidence_strength"], "solver_no_witness")

    def test_nonzero_difference_fails_with_witness(self):
        out = run_with({"status": "DIFFERENCE_FOUND", "solver_calls": 2,
                        "tests": [{"name": "max_difference", "outcome": "OPTIMAL", "value": 12.5,
                                   "witness": {"x": 2.5}},
                                  {"name": "min_difference", "outcome": "OPTIMAL", "value": 0.0}]})
        self.assertEqual(out["status"], "FAIL")
        self.assertEqual(out["evidence_strength"], "solver_witness")

    def test_sense_mismatch_fails(self):
        out = run_with({"status": "SENSE_MISMATCH", "solver_calls": 0,
                        "candidate_sense": "maximize", "required_sense": "minimize"})
        self.assertEqual(out["status"], "FAIL")

    def test_unbounded_difference_fails(self):
        out = run_with({"status": "DIFFERENCE_FOUND", "solver_calls": 2,
                        "message": "objective difference is unbounded",
                        "tests": [{"name": "max_difference", "outcome": "UNBOUNDED"}]})
        self.assertEqual(out["status"], "FAIL")

    def test_infeasible_candidate_is_unresolved_never_pass(self):
        out = run_with({"status": "INCONCLUSIVE", "solver_calls": 2,
                        "message": "candidate feasible region is empty"})
        self.assertEqual(out["status"], "UNRESOLVED")
        self.assertNotEqual(out["status"], "PASS")

    def test_inconclusive_solver_status_is_unresolved(self):
        out = run_with({"status": "INCONCLUSIVE", "solver_calls": 2})
        self.assertEqual(out["status"], "UNRESOLVED")

    def test_unknown_harness_status_defaults_to_unresolved(self):
        out = run_with({"status": "SOMETHING_ELSE", "solver_calls": 0})
        self.assertEqual(out["status"], "UNRESOLVED")


class ContractValidation(unittest.TestCase):
    def ok(self, params):
        return pe.validate_probe(
            {"probe_id": "p", "requirement_id": "R_obj",
             "probe_template": "objective_difference_probe", "claim": "c",
             "parameters": params}, INVENTORY)

    def test_unknown_variable_is_rejected(self):
        good, reason = self.ok({"required_objective": {
            "sense": "minimize", "terms": [{"var": "zzz", "coeff": 1.0}], "constant": 0.0}})
        self.assertFalse(good)
        self.assertIn("unknown_variable", reason)

    def test_non_numeric_coefficient_is_rejected(self):
        good, reason = self.ok({"required_objective": {
            "sense": "minimize", "terms": [{"var": "x", "coeff": "thirty"}], "constant": 0.0}})
        self.assertFalse(good)
        self.assertIn("coefficient_not_numeric", reason)

    def test_missing_sense_is_rejected(self):
        good, _ = self.ok({"required_objective": {
            "terms": [{"var": "x", "coeff": 1.0}], "constant": 0.0}})
        self.assertFalse(good)

    def test_well_formed_contract_is_accepted(self):
        good, _ = self.ok({"required_objective": {
            "sense": "minimize",
            "terms": [{"var": "x", "coeff": 3.0}, {"var": "y", "coeff": 4.0}],
            "constant": 0.0}, "tolerance": 1e-6})
        self.assertTrue(good)


class DiagnosticDemotion(unittest.TestCase):
    def test_check_objective_terms_never_returns_a_verdict_bearing_fail(self):
        source = open(pe.__file__, encoding="utf-8").read()
        start = source.index('    if template == "check_objective_terms":')
        end = start + source[start:].index('"unsupported template"')
        self.assertNotIn('"status": "FAIL"', source[start:end])

    def test_check_objective_terms_is_marked_diagnostic_only(self):
        source = open(pe.__file__, encoding="utf-8").read()
        start = source.index('    if template == "check_objective_terms":')
        end = start + source[start:].index('"unsupported template"')
        self.assertIn('"execution_mode": "diagnostic_only"', source[start:end])


class Schema(unittest.TestCase):
    def test_schema_pins_template_and_requires_numeric_coefficients(self):
        schema = ps.probe_schema("objective_difference_probe", "R_obj")
        self.assertEqual(schema["properties"]["probe_template"]["enum"],
                         ["objective_difference_probe"])
        terms = (schema["properties"]["parameters"]["properties"]
                 ["required_objective"]["properties"]["terms"])
        self.assertEqual(terms["items"]["properties"]["coeff"], {"type": "number"})


if __name__ == "__main__":
    unittest.main(verbosity=1)
