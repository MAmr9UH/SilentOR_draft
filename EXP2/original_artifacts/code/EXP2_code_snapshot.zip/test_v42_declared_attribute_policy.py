#!/usr/bin/env python3
"""General regression tests for the declared-attribute evidence policy.

The fixtures use generic variable families and requirement wording.  They deliberately avoid
problem numbers and benchmark requirement names so the tests exercise semantics rather than IDs.
"""
from __future__ import annotations

import unittest

import shadow_witness_architecture as swa
import structural_evidence as se
import track_b_localization as loc


class DeclaredAttributePolicyTests(unittest.TestCase):
    def _record(self, requirement_text, category, metadata_variables,
                inventory_variables, relation=None):
        requirement = {
            "requirement_id": "declared_rule",
            "requirement_text": requirement_text,
            "category": category,
        }
        metadata = {"variables": metadata_variables}
        if relation is not None:
            metadata["requirement_relation"] = relation
        inventory = {
            "variables": inventory_variables,
            "constraints": [],
            "objective": {"sense": "minimize", "terms": [], "constant": 0.0},
        }
        model_slice = {
            "inventory_sha256": "fixture",
            "variables": inventory_variables,
            "constraints": [],
            "objective": inventory["objective"],
            "slice_counts": {
                "variables": len(inventory_variables), "constraints": 0,
            },
        }
        return se.build_record(inventory, requirement, metadata, model_slice)

    def test_binary_accepts_native_binary(self):
        record = self._record(
            "Activation indicator variables are binary.", "binary_domain",
            [{"variable": "indicator", "meaning": "activation indicator",
              "declared_type": "binary"}],
            [{"name": "indicator_1", "vtype": "B", "lb": 0.0, "ub": 1.0}],
        )
        self.assertEqual(record["status"], "PASS")
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_binary_accepts_integer_with_zero_one_bounds(self):
        record = self._record(
            "Activation indicator variables are binary.", "binary_domain",
            [{"variable": "indicator", "meaning": "activation indicator",
              "declared_type": "binary"}],
            [{"name": "indicator_1", "vtype": "I", "lb": 0.0, "ub": 1.0}],
        )
        self.assertEqual(record["status"], "PASS")

    def test_continuous_zero_one_bounds_are_not_binary(self):
        record = self._record(
            "Activation indicator variables are binary.", "binary_domain",
            [{"variable": "indicator", "meaning": "activation indicator",
              "declared_type": "binary"}],
            [{"name": "indicator_1", "vtype": "C", "lb": 0.0, "ub": 1.0}],
        )
        self.assertEqual(record["status"], "FAIL")
        self.assertEqual(record["rule"], "declared_variable_type")
        self.assertTrue(se.is_authoritative_declared_attribute_failure(record))

    def test_indicator_word_without_explicit_type_is_not_authoritative(self):
        record = self._record(
            "The activation indicator links production to opening.", "linking",
            [{"variable": "indicator", "meaning": "activation indicator",
              "declared_type": "binary"}],
            [{"name": "indicator_1", "vtype": "C", "lb": 0.0, "ub": 1.0}],
        )
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_single_variable_bound_targets_only_exact_relation_member_for_solver(self):
        relation = {
            "lhs_terms": [{"var": "quantity_1", "coeff": 1.0}],
            "sense": ">=",
            "rhs": 0.0,
        }
        record = self._record(
            "The first quantity has the stated lower bound.", "bound",
            [{"variable": "quantity", "meaning": "indexed quantity",
              "declared_type": "continuous"}],
            [
                {"name": "quantity_1", "vtype": "C", "lb": -1.0, "ub": None},
                {"name": "quantity_2", "vtype": "C", "lb": -5.0, "ub": None},
            ],
            relation=relation,
        )
        self.assertEqual(record["target_variables"], ["quantity_1"])
        self.assertEqual(
            [item["variable"] for item in record["offending_variables"]],
            ["quantity_1"],
        )
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertTrue(record["requires_solver_search"])
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_upper_bound_mismatch_requires_solver_search(self):
        relation = {
            "lhs_terms": [{"var": "capacity_1", "coeff": 1.0}],
            "sense": "<=",
            "rhs": 10.0,
        }
        record = self._record(
            "The first capacity variable has the stated upper bound.", "bound",
            [{"variable": "capacity", "meaning": "indexed capacity decision",
              "declared_type": "continuous"}],
            [{"name": "capacity_1", "vtype": "C", "lb": 0.0, "ub": 20.0}],
            relation=relation,
        )
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertEqual(record["rule"], "declared_upper_bound")
        self.assertTrue(record["requires_solver_search"])
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_lower_bound_mismatch_requires_solver_search(self):
        record = self._record(
            "Production quantities are non-negative.", "non_negativity",
            [{"variable": "production", "meaning": "production quantity",
              "declared_type": "integer"}],
            [{"name": "production_1", "vtype": "I", "lb": -1.0, "ub": None}],
        )
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertEqual(record["rule"], "declared_lower_bound")
        self.assertTrue(record["requires_solver_search"])
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_missing_metadata_family_is_unresolved_not_pass(self):
        record = self._record(
            "Production quantities are non-negative.", "non_negativity",
            [{"variable": "production", "meaning": "production quantity",
              "declared_type": "integer"}],
            [{"name": "unrelated_1", "vtype": "I", "lb": 0.0, "ub": None}],
        )
        self.assertEqual(record["status"], "UNRESOLVED")
        self.assertNotEqual(record["coverage"], "FULL")
        self.assertFalse(se.is_authoritative_declared_attribute_failure(record))

    def test_binary_scope_excludes_integer_quantity_family(self):
        record = self._record(
            "Activation indicator variables are binary.", "binary_domain",
            [
                {"variable": "quantity", "meaning": "integer transported quantity",
                 "declared_type": "integer"},
                {"variable": "indicator", "meaning": "binary activation indicator",
                 "declared_type": "binary"},
            ],
            [
                {"name": "quantity_1", "vtype": "I", "lb": 0.0, "ub": None},
                {"name": "indicator_1", "vtype": "C", "lb": 0.0, "ub": 1.0},
            ],
        )
        self.assertEqual(record["target_variables"], ["indicator_1"])
        self.assertEqual(
            [item["variable"] for item in record["offending_variables"]],
            ["indicator_1"],
        )

    def test_semantic_scope_selects_trip_counts_not_shipment_quantities(self):
        record = self._record(
            "Trip count variables are integer.", "integrality",
            [
                {"variable": "shipment", "meaning": "shipped quantity",
                 "declared_type": "integer"},
                {"variable": "trips", "meaning": "number of trips",
                 "declared_type": "integer"},
            ],
            [
                {"name": "shipment_origin_destination", "vtype": "I",
                 "lb": 0.0, "ub": None},
                {"name": "trips_origin_destination", "vtype": "C",
                 "lb": 0.0, "ub": None},
            ],
        )
        self.assertEqual(record["target_variables"], ["trips_origin_destination"])
        self.assertTrue(se.is_authoritative_declared_attribute_failure(record))

    def test_tier_one_ranks_above_other_structural_and_probe_failures(self):
        authoritative = {
            "requirement_id": "declared",
            "result_label": "STRUCTURAL_FAIL",
            "decision_source": "structural_witness",
            "structural_evidence": {
                "status": "FAIL", "sufficient": True, "coverage": "FULL",
                "authoritative_no_witness": True,
                "rule": "declared_variable_type",
                "declared_attribute": "vtype",
                "target_scope": {
                    "scope_valid": True,
                    "unmatched_metadata_target_groups": [],
                },
                "target_variables": ["indicator_1"],
            },
        }
        other_structural = {
            "requirement_id": "structural",
            "result_label": "STRUCTURAL_FAIL",
            "decision_source": "structural_witness",
            "structural_evidence": {
                "status": "FAIL", "sufficient": True, "coverage": "FULL",
                "authoritative_no_witness": False,
            },
        }
        executable = {
            "requirement_id": "executable",
            "result_label": "PROBE_FAIL",
            "decision_source": "probe_witness",
            "execution_result": {"witness_status": "WITNESS_FOUND"},
        }
        labels = {
            "declared": "STRUCTURAL_FAIL",
            "structural": "STRUCTURAL_FAIL",
            "executable": "PROBE_FAIL",
        }
        result = loc.localize([executable, other_structural, authoritative], labels)
        self.assertEqual(result["ranked_requirement_ids"], [
            "declared", "structural", "executable"])
        self.assertEqual(result["primary_suspected_requirement_id"], "declared")

    def test_tier_one_bypasses_root_agent_and_preserves_tiers(self):
        requirements = [
            {"requirement_id": "declared", "requirement_text": "declared attribute"},
            {"requirement_id": "executable", "requirement_text": "executed relation"},
        ]
        confirmed = [
            {"requirement_id": "declared", "evidence_tier": 1,
             "certificate": {"fact": "type mismatch"}},
            {"requirement_id": "executable", "evidence_tier": 3,
             "certificate": {"fact": "counterexample"}},
        ]

        def root_agent_must_not_run(_prompt, _seed, _max_tokens):
            raise AssertionError("Tier-1 evidence must bypass the root agent")

        result = swa.adjudicate_root_cause(
            requirements, confirmed, call_json=root_agent_must_not_run,
            model="fixture", seed=1,
            deterministic_fallback_ranking=["executable", "declared"],
            evidence_tiers={"declared": 1, "executable": 3},
        )
        self.assertFalse(result["model_called"])
        self.assertEqual(result["model_call_count"], 0)
        self.assertFalse(result["root_agent_technical_failure"])
        self.assertEqual(result["ranked_requirement_ids"], ["declared", "executable"])
        self.assertEqual(result["primary_requirement_id"], "declared")
        self.assertEqual(result["call_records"], [])

    def test_policy_table_has_no_benchmark_identifier(self):
        se.assert_generic_rule_table()


if __name__ == "__main__":
    unittest.main()
